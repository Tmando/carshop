class Pizza{
  name:string;
  price:number;
  ingredientsList:Array<String>;
  pizzaImg:string;
  setName(name:string):void{
    this.name = name;
  }
  setPrice(price:number):void{
    this.price = price;
  }
  getName():string{
    return this.name;
  }
  getPrice():number{
    return this.price;
  }
  getPizzaImg():string{
    return this.pizzaImg;
  }
  constructor(name:string,price:number,pizzaImg:string){
    this.name = name;
    this.price = price;
    this.ingredientsList = new Array<String>();
    this.pizzaImg = pizzaImg;
  }

  addIngredients(ingredient:string){
    this.ingredientsList.push(ingredient);
  }

}

class Person{
  forename:string;
  lastName:string;
  email:string;
  address:string;
  constructor(forename:string,lastName:string,email:string,address:string){
    this.forename = forename;
    this.lastName = lastName;
    this.email = email;
    this.address = address;
  }
  getForename():string{
    return this.forename;
  }
  getLastName():string{
    return this.lastName;
  }
  getEmail():string{
    return this.email;
  }
  getAdress():string{
    return this.address;
  }
}

class Restaurant{
  personMap:Map<Number,Person>;
  personIDCount:number;
  pizzaMap:Map<String,Pizza>;
  pizzaNameArray:Array<String>;
  constructor(){
    this.personIDCount = 0;
    this.personMap = new Map<Number,Person>();
    this.pizzaMap = new Map<String,Pizza>();
    this.pizzaNameArray = new Array<String>();
  }
  createPerson(forename:string,lastName:string,email:string,address:string){
    this.personMap.set(this.personIDCount,new Person(forename,lastName,email,address));
    this.personIDCount += 1;

  }
  getAllPerson():void{
    console.log(this.personMap.keys());
    let keys = this.personMap.keys();
    console.log(keys[0]);
    let obj = Object.create(this.personMap);
    for(let prop in this.personMap){
      console.log(prop);
    }
  }
  addPizza(name:string,price:number,img:string):void{
    this.pizzaMap.set(name,new Pizza(name,price,img));
    this.pizzaNameArray.push(name);
  }
  addIngredientsToPizza(pizzaName:string):void{
    let counter:number=1
    if(this.pizzaMap.has(pizzaName)){
      while(counter < arguments.length){
        this.pizzaMap.get(pizzaName).addIngredients(arguments[counter]);
        counter = counter + 1;
      }
      }
    }
    getPizzaRows():string{
      console.log('Hallo');
      let finalStr:string = '';
      for(let i= 0;i<this.pizzaNameArray.length;i++){
          finalStr += this.writeDivTag(this.pizzaMap.get(this.pizzaNameArray[i]));
      }
      // finalStr+='</div>';
      console.log('FinalString',finalStr);
      return finalStr;

    }
    writeDivTag(curPizza:Pizza):string{
      let divMainTag:string ='<div class=\"row\">';
        let divFirstRow:string = '<div class=\"row\">';
          let divFirstRowFirstCol:string = '<div class=\"col-lg-4\">';
                let imgTag = '<img class=\"img-responsive\" src=' + curPizza.getPizzaImg() + '>';
              divFirstRowFirstCol+=imgTag;
              divFirstRowFirstCol+='</div>';
          let divFirstRowSecoundCol:string = '<div class=\"col-lg-4\">';
              let headerTag:string = '<h1>' + curPizza.getName() + '</h1>';
              divFirstRowSecoundCol+=headerTag;
              divFirstRowSecoundCol+=this.divaddIngredients(curPizza);
              divFirstRowSecoundCol+='</div>';
        divFirstRow+=divFirstRowFirstCol;
        divFirstRow+=divFirstRowSecoundCol;
        divFirstRow += '</div>';
          let divSecoundRow = '<div class=\"row\">';
            let divSecoundCol:string = '<div class=\"col-lg-2 col-lg-offset-6\">';
            divSecoundCol += '<button> Add to Cart</button>';
            divSecoundCol += '</div>';
          divSecoundRow+=divSecoundCol;
          divSecoundRow += '</div>';
      divMainTag+=divSecoundRow;
      divMainTag += divFirstRow;
      divMainTag += '</div>';
      return divMainTag;
    }
    divaddIngredients(curPizza:Pizza):string{
      let ulTag:string = '<ul>';
      for(let i:number=0;i<curPizza.ingredientsList.length;i++){
        ulTag += '<li>' + curPizza.ingredientsList[i] + '</li>';
      }
      ulTag+='</ul>';
      return ulTag;
    }
}
