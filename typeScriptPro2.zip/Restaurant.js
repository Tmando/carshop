var Pizza = (function () {
    function Pizza(name, price, pizzaImg) {
        this.name = name;
        this.price = price;
        this.ingredientsList = new Array();
        this.pizzaImg = pizzaImg;
    }
    Pizza.prototype.setName = function (name) {
        this.name = name;
    };
    Pizza.prototype.setPrice = function (price) {
        this.price = price;
    };
    Pizza.prototype.getName = function () {
        return this.name;
    };
    Pizza.prototype.getPrice = function () {
        return this.price;
    };
    Pizza.prototype.getPizzaImg = function () {
        return this.pizzaImg;
    };
    Pizza.prototype.addIngredients = function (ingredient) {
        this.ingredientsList.push(ingredient);
    };
    return Pizza;
}());
var Person = (function () {
    function Person(forename, lastName, email, address) {
        this.forename = forename;
        this.lastName = lastName;
        this.email = email;
        this.address = address;
    }
    Person.prototype.getForename = function () {
        return this.forename;
    };
    Person.prototype.getLastName = function () {
        return this.lastName;
    };
    Person.prototype.getEmail = function () {
        return this.email;
    };
    Person.prototype.getAdress = function () {
        return this.address;
    };
    return Person;
}());
var Restaurant = (function () {
    function Restaurant() {
        this.personIDCount = 0;
        this.personMap = new Map();
        this.pizzaMap = new Map();
        this.pizzaNameArray = new Array();
    }
    Restaurant.prototype.createPerson = function (forename, lastName, email, address) {
        this.personMap.set(this.personIDCount, new Person(forename, lastName, email, address));
        this.personIDCount += 1;
    };
    Restaurant.prototype.getAllPerson = function () {
        console.log(this.personMap.keys());
        var keys = this.personMap.keys();
        console.log(keys[0]);
        var obj = Object.create(this.personMap);
        for (var prop in this.personMap) {
            console.log(prop);
        }
    };
    Restaurant.prototype.addPizza = function (name, price, img) {
        this.pizzaMap.set(name, new Pizza(name, price, img));
        this.pizzaNameArray.push(name);
    };
    Restaurant.prototype.addIngredientsToPizza = function (pizzaName) {
        var counter = 1;
        if (this.pizzaMap.has(pizzaName)) {
            while (counter < arguments.length) {
                this.pizzaMap.get(pizzaName).addIngredients(arguments[counter]);
                counter = counter + 1;
            }
        }
    };
    Restaurant.prototype.getPizzaRows = function () {
        console.log('Hallo');
        var finalStr = '';
        for (var i = 0; i < this.pizzaNameArray.length; i++) {
            finalStr += this.writeDivTag(this.pizzaMap.get(this.pizzaNameArray[i]));
        }
        // finalStr+='</div>';
        console.log('FinalString', finalStr);
        return finalStr;
    };
    Restaurant.prototype.writeDivTag = function (curPizza) {
        var divMainTag = '<div class=\"row\">';
        var divFirstRow = '<div class=\"row\">';
        var divFirstRowFirstCol = '<div class=\"col-lg-4\">';
        var imgTag = '<img class=\"img-responsive\" src=' + curPizza.getPizzaImg() + '>';
        divFirstRowFirstCol += imgTag;
        divFirstRowFirstCol += '</div>';
        var divFirstRowSecoundCol = '<div class=\"col-lg-4\">';
        var headerTag = '<h1>' + curPizza.getName() + '</h1>';
        divFirstRowSecoundCol += headerTag;
        divFirstRowSecoundCol += this.divaddIngredients(curPizza);
        divFirstRowSecoundCol += '</div>';
        divFirstRow += divFirstRowFirstCol;
        divFirstRow += divFirstRowSecoundCol;
        divFirstRow += '</div>';
        var divSecoundRow = '<div class=\"row\">';
        var divSecoundCol = '<div class=\"col-lg-2 col-lg-offset-6\">';
        divSecoundCol += '<button> Add to Cart</button>';
        divSecoundCol += '</div>';
        divSecoundRow += divSecoundCol;
        divSecoundRow += '</div>';
        divMainTag += divSecoundRow;
        divMainTag += divFirstRow;
        divMainTag += '</div>';
        return divMainTag;
    };
    Restaurant.prototype.divaddIngredients = function (curPizza) {
        var ulTag = '<ul>';
        for (var i = 0; i < curPizza.ingredientsList.length; i++) {
            ulTag += '<li>' + curPizza.ingredientsList[i] + '</li>';
        }
        ulTag += '</ul>';
        return ulTag;
    };
    return Restaurant;
}());
